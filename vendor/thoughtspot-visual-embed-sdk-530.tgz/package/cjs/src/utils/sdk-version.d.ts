export declare const version: string;
//# sourceMappingURL=sdk-version.d.ts.map
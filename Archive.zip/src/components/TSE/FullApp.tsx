import { useEffect, useRef } from "react";
import {
  EmbedEvent,
  AppEmbed,
  Page,
  ListPage,
} from "@thoughtspot/visual-embed-sdk";
import { authNone } from "../../auth";

// trustedAuth();
authNone();

const FullApp = () => {
  const refApp = useRef<AppEmbed | null>(null);
  useEffect(() => {
    const appEmbed = new AppEmbed(document.getElementById("tsEmbed")!, {
      frameParams: {
        width: "100%",
        height: "100vh",
      },
      pageId: Page.Home,
      // showPrimaryNavbar: true,
      // modularHomeExperience: false,
      discoveryExperience: {
        // listPageVersion: ListPage.List,
      },
    });
    appEmbed.on(EmbedEvent.AuthExpire, (payload) => {
      console.log("AuthInit", payload);
    });
    refApp.current = appEmbed;
    appEmbed.render();
  }, []);

  return <div className="w-full h-full" id="tsEmbed"></div>;
};

export default FullApp;
